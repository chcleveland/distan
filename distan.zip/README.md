# Distan

A browser strategy game about **school-district consolidation and expansion**,
played in the style of *Settlers of Catan*. Collect education resources from
communities across a county, build bus routes, open schools, and consolidate
them into full district campuses. First to **10 victory points** wins.

**Play:** https://chcleveland.github.io/distan/

## Features

- Hex board with terrain (Neighborhoods, Tax Base, College Towns, Build Sites,
  Print Shops), number tokens, and trading ports
- Five education resources: 🎓 Enrollment, 💰 Funding, 🍎 Teachers,
  🏗️ Facilities, 📚 Supplies
- Setup snake-draft placement, dice production, and the "budget cut" (the
  robber, on a roll of 7) with discard + steal
- Build bus routes / schools / district campuses; buy and play policy cards
  (Administrator, Infrastructure Grant, State Grant, Funding Mandate, and
  landmark victory-point cards)
- Bank & port trading; **Longest Bus Network** and **Strongest Administration**
  bonuses (+2 VP each)
- 2–4 players hot-seat and/or greedy CPU opponents

## Running it

It's plain static HTML/CSS/JS — no build step, no dependencies. Open
`index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000/
```

## Files

| File | Purpose |
|------|---------|
| `index.html` | Start screen, how-to-play, and game UI |
| `game.js` | The full game engine |
| `game.css` | Styles (base theme + game styles, self-contained) |
| `.nojekyll` | Disables Jekyll processing on GitHub Pages (optional) |
| `.github/workflows/pages.yml` | Optional GitHub Actions auto-deploy |

The three files `index.html`, `game.css`, and `game.js` are all that's needed
to play — everything else is optional.

## Publish from your phone (no terminal)

1. In a mobile browser, go to **github.com**, sign in, tap **＋ → New
   repository**. Name it `distan`, set **Public**, tap **Create**.
2. On the new repo, tap **Add file → Upload files**. Select
   `index.html`, `game.css`, and `game.js` (all three at once), then
   **Commit changes**.
3. Tap **Settings → Pages**. Under **Source**, choose **Deploy from a
   branch**, pick branch **main** and folder **/ (root)**, tap **Save**.
4. Wait ~1 minute, then open **https://<your-user>.github.io/distan/** and play.

## Deploying with GitHub Actions (desktop / optional)

This repo also ships `.github/workflows/pages.yml`. To use it, set
**Settings → Pages → Source** to **GitHub Actions**; every push to `main`
then builds and publishes automatically.

## Credits

Built by Christopher Cleveland for the SDP Nebraska Strategic Data Leadership
Network. Not affiliated with CATAN GmbH; "Distan" is an independent,
education-themed game inspired by the Catan style of play.
