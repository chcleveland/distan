/* ============================================================
   Distan — School district consolidation & expansion
   Plain JS, no dependencies. Hot-seat + optional CPU players.
   ============================================================ */
(function () {
  "use strict";

  /* ---------------- Constants & theming ---------------- */
  const RES = ["students", "funding", "teachers", "facilities", "supplies"];
  const RES_META = {
    students:   { name: "Enrollment", short: "Students",   icon: "🎓" },
    funding:    { name: "Funding",    short: "Funding",    icon: "💰" },
    teachers:   { name: "Teachers",   short: "Teachers",   icon: "🍎" },
    facilities: { name: "Facilities", short: "Facilities", icon: "🏗️" },
    supplies:   { name: "Supplies",   short: "Supplies",   icon: "📚" },
  };
  // Which terrain produces which resource (name shown on hex)
  const TERRAIN = {
    students:   "Neighborhood",
    funding:    "Tax Base",
    teachers:   "College Town",
    facilities: "Build Site",
    supplies:   "Print Shop",
    vacant:     "Vacant Lot",
  };

  const COST = {
    road:       { facilities: 1, supplies: 1 },
    settlement: { facilities: 1, supplies: 1, teachers: 1, students: 1 },
    city:       { students: 2, funding: 3 },
    dev:        { funding: 1, teachers: 1, students: 1 },
  };

  const PLAYER_COLORS = [
    { fill: "#c0392b", name: "Red" },
    { fill: "#2471c9", name: "Blue" },
    { fill: "#e08e0b", name: "Orange" },
    { fill: "#2f9e44", name: "Green" },
  ];
  const DEFAULT_NAMES = ["Red County", "Blue Valley", "Orange Unified", "Green Hills"];

  const WIN_VP = 10;
  const HAND_LIMIT = 7;          // discard threshold on a 7
  const LONGEST_MIN = 5;         // min routes for Longest Bus Network
  const ARMY_MIN = 3;            // min administrators for Strongest Administration

  const R = 52;                  // hex radius (center to corner)
  const DX = Math.sqrt(3) * R;   // horizontal spacing
  const DY = 1.5 * R;            // vertical spacing
  const LAYOUT = [3, 4, 5, 4, 3];

  const SVGNS = "http://www.w3.org/2000/svg";

  /* ---------------- RNG ---------------- */
  function rnd(n) { return Math.floor(Math.random() * n); }
  function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  function d6() { return 1 + rnd(6); }

  /* ---------------- Game state ---------------- */
  let G = null;
  let MODE = "idle";  // idle | setupS | setupR | road | settlement | city | robber | roadbuild | none
  let pendingRoadBuilds = 0; // for Infrastructure Grant free roads
  let onVertexPick = null;
  let onEdgePick = null;
  let onHexPick = null;

  /* ---------------- Board geometry ---------------- */
  function key(x, y) { return Math.round(x) + "," + Math.round(y); }

  function buildBoard() {
    const hexes = [];
    LAYOUT.forEach((count, row) => {
      for (let i = 0; i < count; i++) {
        const x = (i - (count - 1) / 2) * DX;
        const y = (row - (LAYOUT.length - 1) / 2) * DY;
        hexes.push({ id: hexes.length, x, y, row, col: i });
      }
    });

    // Corners -> unique vertices
    const vmap = {};        // key -> vertex id
    const vertices = [];
    const emap = {};        // "a-b" -> edge id
    const edges = [];

    function vertexAt(x, y) {
      const k = key(x, y);
      if (vmap[k] === undefined) {
        vmap[k] = vertices.length;
        vertices.push({ id: vertices.length, x, y, hexes: [], edges: [], building: null, port: null });
      }
      return vmap[k];
    }
    function edgeBetween(a, b) {
      const k = Math.min(a, b) + "-" + Math.max(a, b);
      if (emap[k] === undefined) {
        const va = vertices[a], vb = vertices[b];
        emap[k] = edges.length;
        edges.push({ id: edges.length, v: [a, b], mx: (va.x + vb.x) / 2, my: (va.y + vb.y) / 2, road: null });
        va.edges.push(emap[k]); vb.edges.push(emap[k]);
      }
      return emap[k];
    }

    hexes.forEach((h) => {
      const corners = [];
      for (let k = 0; k < 6; k++) {
        const ang = (Math.PI / 180) * (60 * k - 90);
        corners.push(vertexAt(h.x + R * Math.cos(ang), h.y + R * Math.sin(ang)));
      }
      h.corners = corners;
      corners.forEach((v) => { if (!vertices[v].hexes.includes(h.id)) vertices[v].hexes.push(h.id); });
      for (let k = 0; k < 6; k++) edgeBetween(corners[k], corners[(k + 1) % 6]);
    });

    return { hexes, vertices, edges };
  }

  /* ---------------- Terrain + numbers + ports ---------------- */
  function assignTerrain(board) {
    const bag = [];
    const counts = { students: 4, supplies: 4, teachers: 4, facilities: 3, funding: 3 };
    Object.keys(counts).forEach((r) => { for (let i = 0; i < counts[r]; i++) bag.push(r); });
    shuffle(bag);
    // one vacant lot placed at a random hex
    const vacantIdx = rnd(board.hexes.length);
    let bi = 0;
    board.hexes.forEach((h, i) => {
      if (i === vacantIdx) { h.resource = "vacant"; }
      else { h.resource = bag[bi++]; }
    });

    // number tokens (Catan distribution, no 7); assign to producing hexes
    const tokens = [2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12];
    shuffle(tokens);
    let ti = 0;
    board.hexes.forEach((h) => { h.number = h.resource === "vacant" ? null : tokens[ti++]; });

    // robber starts on the vacant lot
    board.hexes.forEach((h) => { h.robber = h.resource === "vacant"; });
    G.robberHex = board.hexes.find((h) => h.robber).id;
  }

  function assignPorts(board) {
    // Perimeter edges = edges belonging to only one hex.
    const hexOfEdge = {};
    board.hexes.forEach((h) => {
      h.corners.forEach((c, k) => {
        const a = h.corners[k], b = h.corners[(k + 1) % 6];
        const ek = Math.min(a, b) + "-" + Math.max(a, b);
        hexOfEdge[ek] = (hexOfEdge[ek] || 0) + 1;
      });
    });
    const perimeter = board.edges.filter((e) => {
      const ek = Math.min(e.v[0], e.v[1]) + "-" + Math.max(e.v[0], e.v[1]);
      return hexOfEdge[ek] === 1;
    });
    // order perimeter edges by angle around center for even spacing
    perimeter.sort((a, b) => Math.atan2(a.my, a.mx) - Math.atan2(b.my, b.mx));

    const portTypes = [
      { type: "any", rate: 3 }, { type: "students", rate: 2 },
      { type: "any", rate: 3 }, { type: "funding", rate: 2 },
      { type: "any", rate: 3 }, { type: "teachers", rate: 2 },
      { type: "any", rate: 3 }, { type: "facilities", rate: 2 },
      { type: "supplies", rate: 2 },
    ];
    const step = Math.floor(perimeter.length / portTypes.length);
    G.ports = [];
    portTypes.forEach((pt, i) => {
      const e = perimeter[(i * step) % perimeter.length];
      const port = { type: pt.type, rate: pt.rate, verts: e.v.slice(), mx: e.mx, my: e.my };
      G.ports.push(port);
      e.v.forEach((v) => { board.vertices[v].port = port; });
    });
  }

  /* ---------------- Init ---------------- */
  function newGame(playerDefs) {
    const board = buildBoard();
    G = {
      board,
      hexes: board.hexes,
      vertices: board.vertices,
      edges: board.edges,
      players: playerDefs.map((p, i) => ({
        id: i, name: p.name, isAI: p.isAI, color: PLAYER_COLORS[i].fill, colorName: PLAYER_COLORS[i].name,
        res: { students: 0, funding: 0, teachers: 0, facilities: 0, supplies: 0 },
        dev: [], newDev: [], playedKnights: 0, vpCards: 0,
        settlements: [], cities: [], roads: [],
        hasLongest: false, hasLargest: false, longestLen: 0,
      })),
      turn: 0,
      phase: "setup",
      setupStep: 0,     // index into setup order
      rolled: false,
      devPlayedThisTurn: false,
      robberHex: null,
      ports: [],
      log: [],
      winner: null,
    };
    assignTerrain(board);
    assignPorts(board);

    // dev card deck
    const deck = [];
    for (let i = 0; i < 14; i++) deck.push("knight");
    for (let i = 0; i < 2; i++) deck.push("roadbuild");
    for (let i = 0; i < 2; i++) deck.push("plenty");
    for (let i = 0; i < 2; i++) deck.push("monopoly");
    const vpNames = ["New Library", "STEM Lab", "Arts Wing", "Athletics Complex", "Early-Ed Center"];
    vpNames.forEach((n) => deck.push("vp:" + n));
    G.devDeck = shuffle(deck);

    // setup order: forward then reverse (snake)
    const n = G.players.length;
    G.setupOrder = [];
    for (let i = 0; i < n; i++) G.setupOrder.push({ p: i, round: 1 });
    for (let i = n - 1; i >= 0; i--) G.setupOrder.push({ p: i, round: 2 });

    renderAll();
    log("Game begins. Place your first school.", null);
    beginSetupStep();
  }

  /* ---------------- Helpers ---------------- */
  function cur() { return G.players[G.turn]; }
  function pip(num) { return num === null ? 0 : 6 - Math.abs(7 - num); }

  function canAfford(pl, cost) { return Object.keys(cost).every((r) => pl.res[r] >= cost[r]); }
  function pay(pl, cost) { Object.keys(cost).forEach((r) => { pl.res[r] -= cost[r]; }); }
  function refund(pl, cost) { Object.keys(cost).forEach((r) => { pl.res[r] += cost[r]; }); }
  function handSize(pl) { return RES.reduce((s, r) => s + pl.res[r], 0); }

  function vertexNeighbors(vId) {
    const v = G.vertices[vId];
    const nb = [];
    v.edges.forEach((eId) => { const e = G.edges[eId]; nb.push(e.v[0] === vId ? e.v[1] : e.v[0]); });
    return nb;
  }

  // Public VP (visible to all) — excludes hidden VP policy cards
  function publicVP(pl) {
    let v = pl.settlements.length + pl.cities.length * 2;
    if (pl.hasLongest) v += 2;
    if (pl.hasLargest) v += 2;
    return v;
  }
  function totalVP(pl) { return publicVP(pl) + pl.vpCards; }

  /* ---------------- Placement validity ---------------- */
  function canPlaceSettlement(vId, pl, requireRoad) {
    const v = G.vertices[vId];
    if (v.building) return false;
    // distance rule: no neighbor may have a building
    for (const nb of vertexNeighbors(vId)) if (G.vertices[nb].building) return false;
    if (requireRoad) {
      const touchesOwnRoad = v.edges.some((eId) => G.edges[eId].road === pl.id);
      if (!touchesOwnRoad) return false;
    }
    return true;
  }

  function canPlaceRoad(eId, pl) {
    const e = G.edges[eId];
    if (e.road !== null) return false;
    // must connect to own building or own road (not passing through opponent building)
    return e.v.some((vId) => {
      const v = G.vertices[vId];
      if (v.building && v.building.player === pl.id) return true;
      if (v.building && v.building.player !== pl.id) return false; // blocked vertex
      return v.edges.some((oe) => oe !== eId && G.edges[oe].road === pl.id);
    });
  }

  function anyValidSettlement(pl, requireRoad) {
    return G.vertices.some((v) => canPlaceSettlement(v.id, pl, requireRoad));
  }
  function anyValidRoad(pl) { return G.edges.some((e) => canPlaceRoad(e.id, pl)); }

  /* ---------------- Rendering ---------------- */
  const svg = document.getElementById("board");

  function el(tag, attrs, parent) {
    const n = document.createElementNS(SVGNS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }

  function hexPoints(h) {
    const pts = [];
    for (let k = 0; k < 6; k++) {
      const ang = (Math.PI / 180) * (60 * k - 90);
      pts.push((h.x + R * Math.cos(ang)).toFixed(1) + "," + (h.y + R * Math.sin(ang)).toFixed(1));
    }
    return pts.join(" ");
  }

  function renderBoard() {
    svg.innerHTML = "";
    const gPorts = el("g", {}, svg);
    const gHex = el("g", {}, svg);
    const gEdge = el("g", {}, svg);
    const gVert = el("g", {}, svg);
    const gRobber = el("g", {}, svg);

    // Ports
    G.ports.forEach((port) => {
      const cx = port.mx * 1.18, cy = port.my * 1.18;
      port.verts.forEach((v) => {
        el("line", { class: "port-link", x1: cx, y1: cy, x2: G.vertices[v].x, y2: G.vertices[v].y }, gPorts);
      });
      el("rect", { class: "port-bg", x: cx - 20, y: cy - 13, width: 40, height: 26, rx: 6 }, gPorts);
      const label = port.type === "any" ? "3:1" : "2:1";
      el("text", { class: "port", x: cx, y: cy - 4 }, gPorts).textContent = label;
      const t2 = el("text", { class: "port", x: cx, y: cy + 7, style: "font-size:12px" }, gPorts);
      t2.textContent = port.type === "any" ? "★" : RES_META[port.type].icon;
    });

    // Hexes
    G.hexes.forEach((h) => {
      const poly = el("polygon", { class: "hex " + h.resource, points: hexPoints(h), "data-hex": h.id }, gHex);
      if (MODE === "robber" && h.id !== G.robberHex) poly.classList.add("moveable");
      poly.addEventListener("click", () => onHexClick(h.id));
      el("text", { class: "hex-label", x: h.x, y: h.y + R * 0.62 }, gHex).textContent = TERRAIN[h.resource];
      if (h.number !== null) {
        el("circle", { class: "num-token", cx: h.x, cy: h.y - 4, r: 15 }, gHex);
        const hot = h.number === 6 || h.number === 8;
        el("text", { class: "num-text" + (hot ? " hot" : ""), x: h.x, y: h.y - 4 }, gHex).textContent = h.number;
        // pips
        const p = pip(h.number); const pw = (p - 1) * 4;
        for (let i = 0; i < p; i++) el("circle", { class: "num-pips", cx: h.x - pw / 2 + i * 4, cy: h.y + 11, r: 1.5 }, gHex);
      }
    });

    // Edges (roads)
    G.edges.forEach((e) => {
      const v0 = G.vertices[e.v[0]], v1 = G.vertices[e.v[1]];
      let cls = "edge";
      if (e.road !== null) cls += " road";
      const line = el("line", { class: cls, x1: v0.x, y1: v0.y, x2: v1.x, y2: v1.y, "data-edge": e.id }, gEdge);
      if (e.road !== null) line.setAttribute("stroke", G.players[e.road].color);
      let clickable = (MODE === "setupR" || MODE === "road" || MODE === "roadbuild") &&
        canPlaceRoad(e.id, cur());
      if (clickable && MODE === "setupR") clickable = e.v.includes(G.setupPendingVertex);
      if (clickable) { line.classList.add("clickable"); line.addEventListener("click", () => onEdgeClick(e.id)); }
    });

    // Vertices (buildings + placement spots)
    G.vertices.forEach((v) => {
      if (v.building) {
        const col = G.players[v.building.player].color;
        if (v.building.type === "city") {
          el("rect", { class: "vertex-dot", x: v.x - 11, y: v.y - 11, width: 22, height: 22, rx: 4,
            fill: col, stroke: "#fff", "stroke-width": 2.5 }, gVert);
          el("rect", { class: "vertex-dot", x: v.x - 5, y: v.y - 16, width: 10, height: 8,
            fill: col, stroke: "#fff", "stroke-width": 1.5 }, gVert);
        } else {
          el("circle", { class: "vertex-dot", cx: v.x, cy: v.y, r: 10, fill: col, stroke: "#fff", "stroke-width": 2.5 }, gVert);
        }
      }
      const requireRoad = MODE === "settlement";
      const showSpot = (MODE === "setupS" || MODE === "settlement") && canPlaceSettlement(v.id, cur(), requireRoad);
      const showCity = MODE === "city" && v.building && v.building.player === cur().id && v.building.type === "settlement";
      if (showSpot) {
        const c = el("circle", { class: "vspot", cx: v.x, cy: v.y, r: 9 }, gVert);
        c.addEventListener("click", () => onVertexClick(v.id));
      } else if (showCity) {
        const c = el("circle", { class: "vspot", cx: v.x, cy: v.y, r: 12 }, gVert);
        c.addEventListener("click", () => onVertexClick(v.id));
      }
    });

    // Robber
    const rh = G.hexes[G.robberHex];
    if (rh) {
      el("circle", { class: "robber", cx: rh.x + 22, cy: rh.y - 18, r: 11 }, gRobber);
      el("text", { x: rh.x + 22, y: rh.y - 18, "text-anchor": "middle", "dominant-baseline": "central",
        "font-size": "12", fill: "#fff", "font-weight": "700" }, gRobber).textContent = "✂";
    }
  }

  function renderHand() {
    const pl = G.players[G.viewPlayer !== undefined ? G.viewPlayer : G.turn];
    const hr = document.getElementById("hand-resources");
    hr.innerHTML = "";
    RES.forEach((r) => {
      const c = document.createElement("div");
      c.className = "rescard " + r;
      c.innerHTML = '<span class="ic">' + RES_META[r].icon + '</span><span class="ct">' + pl.res[r] +
        '</span><span class="nm">' + RES_META[r].short + "</span>";
      hr.appendChild(c);
    });

    const hd = document.getElementById("hand-dev");
    hd.innerHTML = "";
    const all = pl.dev.concat(pl.newDev);
    if (all.length === 0) { hd.innerHTML = '<span class="empty">No policy cards yet.</span>'; }
    const devInfo = {
      knight: { t: "Administrator", d: "Move the budget cut & steal" },
      roadbuild: { t: "Infrastructure Grant", d: "Build 2 free bus routes" },
      plenty: { t: "State Grant", d: "Take any 2 resources" },
      monopoly: { t: "Funding Mandate", d: "Name a resource; take all" },
    };
    const grouped = {};
    pl.dev.forEach((d) => { grouped[d] = (grouped[d] || 0) + 1; });
    Object.keys(grouped).forEach((d) => {
      const isVP = d.startsWith("vp:");
      const info = isVP ? { t: d.slice(3), d: "Landmark — 1 victory point" } : devInfo[d];
      const card = document.createElement("div");
      const playable = !isVP && !G.devPlayedThisTurn && G.phase === "play" && !pl.isAI && G.turn === pl.id && MODE === "idle";
      card.className = "devcard" + (playable ? "" : " locked");
      card.innerHTML = "<b>" + info.t + (grouped[d] > 1 ? " ×" + grouped[d] : "") + "</b><span class='small'>" + info.d + "</span>";
      if (playable) card.addEventListener("click", () => playDev(d));
      hd.appendChild(card);
    });
    pl.newDev.forEach((d) => {
      const isVP = d.startsWith("vp:");
      const info = isVP ? { t: d.slice(3), d: "Landmark — 1 VP" } : devInfo[d];
      const card = document.createElement("div");
      card.className = "devcard locked";
      card.innerHTML = "<b>" + info.t + "</b><span class='small'>Bought this turn</span>";
      hd.appendChild(card);
    });
  }

  function renderScore() {
    const sb = document.getElementById("scoreboard");
    sb.innerHTML = "";
    G.players.forEach((pl) => {
      const row = document.createElement("div");
      row.className = "score-row" + (pl.id === G.turn ? " active" : "") + (pl.isAI ? " aiflag" : "");
      const badges = (pl.hasLongest ? "🚌" : "") + (pl.hasLargest ? "🏛️" : "");
      row.innerHTML =
        '<span class="swatch" style="background:' + pl.color + '"></span>' +
        '<span class="pname">' + escapeHtml(pl.name) + "</span>" +
        '<span class="pmeta">' + pl.settlements.length + "🏫 " + pl.cities.length + "🏛 · " +
        handSize(pl) + " cards · " + pl.dev.filter((d) => d === "knight").length + "👔</span>" +
        '<span class="badge">' + badges + "</span>" +
        '<span class="vp">' + publicVP(pl) + "</span>";
      sb.appendChild(row);
    });
  }

  function renderActions() {
    const bar = document.getElementById("action-bar");
    bar.innerHTML = "";
    const pl = cur();

    if (G.phase === "setup") {
      const banner = MODE === "setupS" ? "Click a highlighted corner to place a school."
        : "Click a highlighted edge to place a bus route.";
      setBanner("<b>" + escapeHtml(pl.name) + "</b> — setup. " + banner);
      return;
    }

    if (G.winner !== null) return;

    if (pl.isAI) { setBanner("<b>" + escapeHtml(pl.name) + "</b> (CPU) is taking its turn…"); return; }

    if (MODE === "robber") { setBanner("<b>" + escapeHtml(pl.name) + "</b> — move the budget cut ✂ to a new community."); return; }
    if (MODE === "road" || MODE === "roadbuild") { setBanner("Click an edge to place your bus route. <a href='#' id='cancelMode'>Cancel</a>"); wireCancel(); return; }
    if (MODE === "settlement") { setBanner("Click a corner to build a school. <a href='#' id='cancelMode'>Cancel</a>"); wireCancel(); return; }
    if (MODE === "city") { setBanner("Click one of your schools to upgrade it to a district campus. <a href='#' id='cancelMode'>Cancel</a>"); wireCancel(); return; }

    if (!G.rolled) {
      const b = mkBtn("🎲 Roll the year", "btn-primary full", roll);
      bar.appendChild(b);
      setBanner("<b>" + escapeHtml(pl.name) + "</b> — roll to collect this year's resources.");
      return;
    }

    // action buttons
    bar.appendChild(mkBtn("Build bus route<span class='cost'>🏗️ 📚</span>", "btn-ghost",
      () => startBuild("road"), !canAfford(pl, COST.road) || !anyValidRoad(pl)));
    bar.appendChild(mkBtn("Build school<span class='cost'>🏗️📚🍎🎓</span>", "btn-ghost",
      () => startBuild("settlement"), !canAfford(pl, COST.settlement) || !anyValidSettlement(pl, true)));
    bar.appendChild(mkBtn("Consolidate campus<span class='cost'>🎓🎓 💰💰💰</span>", "btn-ghost",
      () => startBuild("city"), !canAfford(pl, COST.city) || pl.settlements.length === 0));
    bar.appendChild(mkBtn("Buy policy card<span class='cost'>💰🍎🎓</span>", "btn-ghost",
      () => buyDev(), !canAfford(pl, COST.dev) || G.devDeck.length === 0));
    bar.appendChild(mkBtn("Trade with bank", "btn-ghost", openTrade));
    bar.appendChild(mkBtn("End turn", "btn-primary", endTurn));

    setBanner("<b>" + escapeHtml(pl.name) + "</b> — build, trade, or end your turn.");
  }

  function wireCancel() {
    const c = document.getElementById("cancelMode");
    if (c) c.addEventListener("click", (e) => { e.preventDefault(); MODE = "idle"; renderAll(); });
  }

  function mkBtn(html, cls, fn, disabled) {
    const b = document.createElement("button");
    b.className = "btn btn-sm " + (cls || "");
    b.innerHTML = html;
    if (disabled) b.disabled = true; else b.addEventListener("click", fn);
    return b;
  }

  function setBanner(html) { document.getElementById("turn-banner").innerHTML = html; }

  function renderAll() {
    G.viewPlayer = G.turn;
    renderBoard();
    renderHand();
    renderScore();
    renderActions();
  }

  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  /* ---------------- Log ---------------- */
  function log(msg, pl) {
    const box = document.getElementById("log");
    const e = document.createElement("div");
    e.className = "entry";
    const who = pl ? '<span class="who" style="color:' + pl.color + '">' + escapeHtml(pl.name) + ":</span> " : "";
    e.innerHTML = who + msg;
    box.appendChild(e);
    box.scrollTop = box.scrollHeight;
  }

  /* ---------------- Setup phase ---------------- */
  function beginSetupStep() {
    if (G.setupStep >= G.setupOrder.length) { endSetup(); return; }
    const step = G.setupOrder[G.setupStep];
    G.turn = step.p;
    MODE = "setupS";
    renderAll();
    if (cur().isAI) setTimeout(aiSetup, 550);
  }

  function endSetup() {
    G.phase = "play";
    G.turn = 0;
    G.rolled = false;
    G.devPlayedThisTurn = false;
    MODE = "idle";
    log("Setup complete. " + escapeHtml(G.players[0].name) + " starts.", null);
    renderAll();
    maybeAITurn();
  }

  function placeSetupSettlement(vId) {
    const pl = cur();
    const step = G.setupOrder[G.setupStep];
    G.vertices[vId].building = { type: "settlement", player: pl.id };
    pl.settlements.push(vId);
    log("built a school.", pl);
    // second settlement grants starting resources
    if (step.round === 2) {
      G.vertices[vId].hexes.forEach((hId) => {
        const h = G.hexes[hId];
        if (h.resource !== "vacant") pl.res[h.resource] += 1;
      });
    }
    MODE = "setupR";
    G.setupPendingVertex = vId;
    renderAll();
    if (pl.isAI) setTimeout(aiSetupRoad, 500);
  }

  function placeSetupRoad(eId) {
    const pl = cur();
    G.edges[eId].road = pl.id;
    pl.roads.push(eId);
    log("added a bus route.", pl);
    G.setupStep++;
    G.setupPendingVertex = null;
    beginSetupStep();
  }

  /* ---------------- Dice / production ---------------- */
  function roll() {
    if (G.rolled) return;
    const a = d6(), b = d6(), total = a + b;
    G.rolled = true;
    document.getElementById("die1").textContent = a;
    document.getElementById("die2").textContent = b;
    document.getElementById("die1").classList.add("rolling");
    document.getElementById("die2").classList.add("rolling");
    document.getElementById("dice-total").innerHTML = "rolled <b>" + total + "</b>";
    setTimeout(() => { document.getElementById("die1").classList.remove("rolling"); document.getElementById("die2").classList.remove("rolling"); }, 500);
    log("rolled a <b>" + total + "</b>.", cur());

    if (total === 7) { handleSeven(); return; }
    distribute(total);
    renderAll();
    if (cur().isAI) setTimeout(aiPlay, 650);
  }

  function distribute(total) {
    const gains = G.players.map(() => ({ students: 0, funding: 0, teachers: 0, facilities: 0, supplies: 0 }));
    G.hexes.forEach((h) => {
      if (h.number !== total || h.robber || h.resource === "vacant") return;
      h.corners.forEach((vId) => {
        const v = G.vertices[vId];
        if (!v.building) return;
        const amt = v.building.type === "city" ? 2 : 1;
        gains[v.building.player][h.resource] += amt;
      });
    });
    let any = false;
    G.players.forEach((pl, i) => {
      RES.forEach((r) => { if (gains[i][r] > 0) { pl.res[r] += gains[i][r]; any = true; } });
      const parts = RES.filter((r) => gains[i][r] > 0).map((r) => gains[i][r] + RES_META[r].icon);
      if (parts.length) log("collected " + parts.join(" "), pl);
    });
    if (!any) log("No district collected on that roll.", null);
  }

  /* ---------------- The 7: discard + robber ---------------- */
  function handleSeven() {
    log("A budget cut! (rolled 7)", null);
    const needDiscard = G.players.filter((pl) => handSize(pl) > HAND_LIMIT);
    // AI discards immediately; humans use modal chain
    const humans = needDiscard.filter((pl) => !pl.isAI);
    needDiscard.filter((pl) => pl.isAI).forEach((pl) => aiDiscard(pl));

    if (humans.length === 0) { proceedToRobber(); return; }
    discardChain(humans, 0);
  }

  function discardChain(list, idx) {
    if (idx >= list.length) { proceedToRobber(); return; }
    openDiscardModal(list[idx], () => discardChain(list, idx + 1));
  }

  function proceedToRobber() {
    if (cur().isAI) { setTimeout(() => aiMoveRobber(), 500); return; }
    MODE = "robber";
    renderAll();
  }

  function moveRobber(hexId, byPlayer, cb) {
    G.hexes[G.robberHex].robber = false;
    G.robberHex = hexId;
    G.hexes[hexId].robber = true;
    log("moved the budget cut to " + TERRAIN[G.hexes[hexId].resource] + ".", byPlayer);
    // steal target: players with a building on this hex (not self)
    const victims = new Set();
    G.hexes[hexId].corners.forEach((vId) => {
      const v = G.vertices[vId];
      if (v.building && v.building.player !== byPlayer.id && handSize(G.players[v.building.player]) > 0)
        victims.add(v.building.player);
    });
    const vlist = [...victims];
    if (vlist.length === 0) { if (cb) cb(); return; }
    if (byPlayer.isAI) {
      // steal from the richest victim
      vlist.sort((a, b) => handSize(G.players[b]) - handSize(G.players[a]));
      stealFrom(byPlayer, G.players[vlist[0]]);
      if (cb) cb();
    } else if (vlist.length === 1) {
      stealFrom(byPlayer, G.players[vlist[0]]);
      if (cb) cb();
    } else {
      chooseVictim(byPlayer, vlist, cb);
    }
  }

  function stealFrom(thief, victim) {
    const pool = [];
    RES.forEach((r) => { for (let i = 0; i < victim.res[r]; i++) pool.push(r); });
    if (pool.length === 0) return;
    const r = pool[rnd(pool.length)];
    victim.res[r]--; thief.res[r]++;
    log("stole a resource from " + escapeHtml(victim.name) + ".", thief);
  }

  /* ---------------- Building actions (play phase) ---------------- */
  function startBuild(type) {
    const pl = cur();
    if (type === "road") { if (!canAfford(pl, COST.road)) return; MODE = "road"; }
    else if (type === "settlement") { if (!canAfford(pl, COST.settlement)) return; MODE = "settlement"; }
    else if (type === "city") { if (!canAfford(pl, COST.city)) return; MODE = "city"; }
    renderAll();
  }

  function buildRoad(eId, free) {
    const pl = cur();
    if (!free) pay(pl, COST.road);
    G.edges[eId].road = pl.id;
    pl.roads.push(eId);
    log("built a bus route.", pl);
    updateLongestRoad();
    MODE = "idle";
    renderAll();
    checkWin();
  }

  function buildSettlement(vId) {
    const pl = cur();
    pay(pl, COST.settlement);
    G.vertices[vId].building = { type: "settlement", player: pl.id };
    pl.settlements.push(vId);
    log("opened a new school.", pl);
    updateLongestRoad(); // opponent roads can be cut
    MODE = "idle";
    renderAll();
    checkWin();
  }

  function buildCity(vId) {
    const pl = cur();
    pay(pl, COST.city);
    G.vertices[vId].building = { type: "city", player: pl.id };
    pl.settlements = pl.settlements.filter((s) => s !== vId);
    pl.cities.push(vId);
    log("consolidated a school into a district campus. 🏛️", pl);
    MODE = "idle";
    renderAll();
    checkWin();
  }

  function buyDev() {
    const pl = cur();
    if (!canAfford(pl, COST.dev) || G.devDeck.length === 0) return;
    pay(pl, COST.dev);
    const card = G.devDeck.pop();
    if (card.startsWith("vp:")) { pl.dev.push(card); pl.vpCards++; log("filed a landmark policy. 🏆", pl); checkWin(); }
    else { pl.newDev.push(card); log("bought a policy card.", pl); }
    renderAll();
  }

  /* ---------------- Dev cards ---------------- */
  function playDev(type) {
    const pl = cur();
    if (G.devPlayedThisTurn || pl.isAI) return;
    if (type.startsWith("vp:")) return;
    // remove one from dev (not newDev)
    const i = pl.dev.indexOf(type);
    if (i < 0) return;
    pl.dev.splice(i, 1);
    G.devPlayedThisTurn = true;

    if (type === "knight") {
      pl.playedKnights++;
      log("deployed an Administrator. 👔", pl);
      updateLargestArmy();
      MODE = "robber";
      renderAll();
    } else if (type === "roadbuild") {
      log("used an Infrastructure Grant — 2 free routes.", pl);
      pendingRoadBuilds = 2;
      startRoadBuild();
    } else if (type === "plenty") {
      log("received a State Grant.", pl);
      openPlentyModal();
    } else if (type === "monopoly") {
      openMonopolyModal();
    }
  }

  function startRoadBuild() {
    const pl = cur();
    if (pendingRoadBuilds <= 0 || !anyValidRoad(pl)) { pendingRoadBuilds = 0; MODE = "idle"; renderAll(); return; }
    MODE = "roadbuild";
    renderAll();
  }

  /* ---------------- Longest road / largest army ---------------- */
  function longestRoadFor(pi) {
    const adj = {};
    G.edges.forEach((e) => {
      if (e.road !== pi) return;
      const [a, b] = e.v;
      (adj[a] = adj[a] || []).push({ to: b, e: e.id });
      (adj[b] = adj[b] || []).push({ to: a, e: e.id });
    });
    const blocked = (v) => { const b = G.vertices[v].building; return b && b.player !== pi; };
    let best = 0;
    function dfs(v, used, len) {
      if (len > best) best = len;
      if (blocked(v)) return;              // cannot pass through opponent building
      for (const nb of (adj[v] || [])) {
        if (used.has(nb.e)) continue;
        used.add(nb.e);
        dfs(nb.to, used, len + 1);
        used.delete(nb.e);
      }
    }
    Object.keys(adj).forEach((v) => dfs(+v, new Set(), 0));
    return best;
  }

  function updateLongestRoad() {
    G.players.forEach((pl) => { pl.longestLen = longestRoadFor(pl.id); });
    const holder = G.players.find((pl) => pl.hasLongest);
    let best = LONGEST_MIN - 1, bestPl = null;
    G.players.forEach((pl) => { if (pl.longestLen > best) { best = pl.longestLen; bestPl = pl; } });

    if (!bestPl) { // nobody qualifies; if holder dropped below min, revoke
      if (holder && holder.longestLen < LONGEST_MIN) { holder.hasLongest = false; log("lost the Longest Bus Network.", holder); }
      return;
    }
    if (holder) {
      if (holder.longestLen >= bestPl.longestLen) return; // holder keeps on tie
      holder.hasLongest = false;
    }
    // check for unique leader (ties: nobody takes it from unheld state)
    const tied = G.players.filter((pl) => pl.longestLen === best);
    if (tied.length === 1) {
      if (!bestPl.hasLongest) { bestPl.hasLongest = true; log("claimed the Longest Bus Network! (+2 VP)", bestPl); }
    }
  }

  function updateLargestArmy() {
    const holder = G.players.find((pl) => pl.hasLargest);
    let best = ARMY_MIN - 1, bestPl = null;
    G.players.forEach((pl) => { if (pl.playedKnights > best) { best = pl.playedKnights; bestPl = pl; } });
    if (!bestPl) return;
    if (holder) {
      if (holder.playedKnights >= bestPl.playedKnights) return;
      holder.hasLargest = false;
    }
    if (!bestPl.hasLargest) { bestPl.hasLargest = true; log("earned the Strongest Administration! (+2 VP)", bestPl); }
  }

  /* ---------------- Turn flow ---------------- */
  function endTurn() {
    const pl = cur();
    // move newly bought dev cards into playable hand
    pl.dev = pl.dev.concat(pl.newDev);
    pl.newDev = [];
    G.rolled = false;
    G.devPlayedThisTurn = false;
    pendingRoadBuilds = 0;
    MODE = "idle";
    G.turn = (G.turn + 1) % G.players.length;
    document.getElementById("die1").textContent = "–";
    document.getElementById("die2").textContent = "–";
    document.getElementById("dice-total").textContent = "";
    renderAll();
    maybeAITurn();
  }

  function checkWin() {
    const pl = cur();
    if (totalVP(pl) >= WIN_VP) {
      G.winner = pl.id;
      renderAll();
      openWinModal(pl);
    }
  }

  /* ---------------- Click routing ---------------- */
  function onVertexClick(vId) {
    if (G.winner !== null) return;
    const pl = cur();
    if (MODE === "setupS") {
      if (canPlaceSettlement(vId, pl, false)) placeSetupSettlement(vId);
    } else if (MODE === "settlement") {
      if (canPlaceSettlement(vId, pl, true)) buildSettlement(vId);
    } else if (MODE === "city") {
      const v = G.vertices[vId];
      if (v.building && v.building.player === pl.id && v.building.type === "settlement") buildCity(vId);
    }
  }

  function onEdgeClick(eId) {
    if (G.winner !== null) return;
    const pl = cur();
    if (!canPlaceRoad(eId, pl)) return;
    if (MODE === "setupR") { if (G.edges[eId].v.includes(G.setupPendingVertex)) placeSetupRoad(eId); }
    else if (MODE === "road") buildRoad(eId, false);
    else if (MODE === "roadbuild") {
      buildRoad(eId, true);
      pendingRoadBuilds--;
      if (pendingRoadBuilds > 0 && anyValidRoad(pl)) startRoadBuild();
      else { pendingRoadBuilds = 0; MODE = "idle"; renderAll(); }
    }
  }

  function onHexClick(hexId) {
    if (MODE !== "robber" || hexId === G.robberHex) return;
    moveRobber(hexId, cur(), () => { MODE = "idle"; renderAll(); checkWin(); });
  }

  /* ---------------- Bank / port trading ---------------- */
  function tradeRate(pl, giveRes) {
    let rate = 4;
    // ports on player's building vertices
    pl.settlements.concat(pl.cities).forEach((vId) => {
      const port = G.vertices[vId].port;
      if (!port) return;
      if (port.type === "any") rate = Math.min(rate, 3);
      if (port.type === giveRes) rate = Math.min(rate, 2);
    });
    return rate;
  }

  function openTrade() {
    const pl = cur();
    const body = document.createElement("div");
    body.innerHTML = "<p class='small'>Trade resources with the bank. Your rate improves if you have a school on a trading port.</p>";

    const state = { give: null, get: null };
    const grid = document.createElement("div");
    grid.className = "trade-grid";

    const giveCol = document.createElement("div"); giveCol.className = "trade-col";
    giveCol.innerHTML = "<h4>You give</h4>";
    RES.forEach((r) => {
      const rate = tradeRate(pl, r);
      const opt = document.createElement("div"); opt.className = "trade-opt";
      const btn = document.createElement("button"); btn.className = "btn btn-sm btn-ghost";
      btn.innerHTML = RES_META[r].icon + " " + rate + "×";
      btn.disabled = pl.res[r] < rate;
      btn.addEventListener("click", () => { state.give = r; highlight(giveCol, btn); refreshGetBtns(); });
      opt.appendChild(btn);
      opt.appendChild(document.createTextNode(" have " + pl.res[r]));
      giveCol.appendChild(opt);
    });

    const arrow = document.createElement("div"); arrow.textContent = "→"; arrow.style.fontSize = "24px"; arrow.style.textAlign = "center";

    const getCol = document.createElement("div"); getCol.className = "trade-col";
    getCol.innerHTML = "<h4>You get</h4>";
    const getBtns = {};
    RES.forEach((r) => {
      const opt = document.createElement("div"); opt.className = "trade-opt";
      const btn = document.createElement("button"); btn.className = "btn btn-sm btn-ghost";
      btn.innerHTML = RES_META[r].icon + " +1";
      btn.addEventListener("click", () => { state.get = r; highlight(getCol, btn); });
      getBtns[r] = btn; opt.appendChild(btn); getCol.appendChild(opt);
    });
    function refreshGetBtns() { RES.forEach((r) => { getBtns[r].disabled = (r === state.give); }); }

    grid.appendChild(giveCol); grid.appendChild(arrow); grid.appendChild(getCol);
    body.appendChild(grid);

    function highlight(col, btn) {
      col.querySelectorAll("button").forEach((b) => b.classList.remove("btn-primary"));
      btn.classList.remove("btn-ghost"); btn.classList.add("btn-primary");
    }

    openModal("Trade with the bank", body, [
      { label: "Confirm trade", cls: "btn-primary", fn: () => {
          if (!state.give || !state.get || state.give === state.get) return;
          const rate = tradeRate(pl, state.give);
          if (pl.res[state.give] < rate) return;
          pl.res[state.give] -= rate; pl.res[state.get] += 1;
          log("traded " + rate + RES_META[state.give].icon + " → 1" + RES_META[state.get].icon + " with the bank.", pl);
          closeModal(); renderAll();
        } },
      { label: "Cancel", cls: "btn-ghost", fn: closeModal },
    ]);
  }

  /* ---------------- Modals ---------------- */
  const backdrop = document.getElementById("modal-backdrop");
  function openModal(title, bodyNode, actions) {
    document.getElementById("modal-title").textContent = title;
    const body = document.getElementById("modal-body");
    body.innerHTML = ""; body.appendChild(bodyNode);
    const act = document.getElementById("modal-actions");
    act.innerHTML = "";
    (actions || []).forEach((a) => {
      const b = document.createElement("button");
      b.className = "btn " + (a.cls || "btn-ghost");
      b.textContent = a.label;
      b.addEventListener("click", a.fn);
      act.appendChild(b);
    });
    backdrop.hidden = false;
  }
  function closeModal() { backdrop.hidden = true; }

  function openDiscardModal(pl, done) {
    const need = Math.floor(handSize(pl) / 2);
    const sel = { students: 0, funding: 0, teachers: 0, facilities: 0, supplies: 0 };
    const body = document.createElement("div");
    const info = document.createElement("p");
    info.innerHTML = "<b>" + escapeHtml(pl.name) + "</b>, the budget cut forces you to discard <b>" + need + "</b> of your " + handSize(pl) + " cards.";
    body.appendChild(info);
    const status = document.createElement("p"); status.className = "small";

    function chosenCount() { return RES.reduce((s, r) => s + sel[r], 0); }
    function refresh() {
      const c = chosenCount();
      status.textContent = "Selected " + c + " / " + need;
      const rc = document.querySelector("#modal-actions .btn-primary");
      if (rc) rc.disabled = c !== need;
    }

    RES.forEach((r) => {
      const row = document.createElement("div"); row.className = "give-row";
      row.innerHTML = "<span>" + RES_META[r].icon + " " + RES_META[r].name + " (have " + pl.res[r] + ")</span>";
      const step = document.createElement("div"); step.className = "stepper";
      const minus = document.createElement("button"); minus.textContent = "−";
      const cnt = document.createElement("span");
      cnt.textContent = "0"; cnt.style.minWidth = "18px"; cnt.style.textAlign = "center"; cnt.style.display = "inline-block";
      const plus = document.createElement("button"); plus.textContent = "+";
      minus.addEventListener("click", () => { if (sel[r] > 0) { sel[r]--; cnt.textContent = sel[r]; refresh(); } });
      plus.addEventListener("click", () => {
        if (sel[r] < pl.res[r] && chosenCount() < need) { sel[r]++; cnt.textContent = sel[r]; refresh(); }
      });
      step.appendChild(minus); step.appendChild(cnt); step.appendChild(plus);
      row.appendChild(step); body.appendChild(row);
    });
    body.appendChild(status);

    openModal("Budget cut — discard", body, [{
      label: "Discard", cls: "btn-primary", fn: () => {
        if (chosenCount() !== need) return;
        RES.forEach((r) => { pl.res[r] -= sel[r]; });
        log("discarded " + need + " cards to the budget cut.", pl);
        closeModal(); done();
      },
    }]);
    refresh();
  }

  function chooseVictim(thief, vlist, cb) {
    const body = document.createElement("div");
    body.innerHTML = "<p>Choose a district to steal one resource from:</p>";
    const wrap = document.createElement("div");
    vlist.forEach((pid) => {
      const v = G.players[pid];
      const b = document.createElement("button");
      b.className = "btn btn-ghost"; b.style.margin = "4px";
      b.innerHTML = '<span style="color:' + v.color + '">●</span> ' + escapeHtml(v.name) + " (" + handSize(v) + " cards)";
      b.addEventListener("click", () => { stealFrom(thief, v); closeModal(); if (cb) cb(); });
      wrap.appendChild(b);
    });
    body.appendChild(wrap);
    openModal("Steal a resource", body, []);
  }

  function openPlentyModal() {
    const pl = cur();
    const picks = [];
    const body = document.createElement("div");
    body.innerHTML = "<p>State Grant: choose <b>2</b> resources to take from the bank.</p>";
    const status = document.createElement("p"); status.className = "small";
    RES.forEach((r) => {
      const b = document.createElement("button"); b.className = "btn btn-ghost"; b.style.margin = "3px";
      b.innerHTML = RES_META[r].icon + " " + RES_META[r].name;
      b.addEventListener("click", () => { if (picks.length < 2) { picks.push(r); status.textContent = "Chosen: " + picks.map((x) => RES_META[x].short).join(", "); if (picks.length === 2) confirm.disabled = false; } });
      body.appendChild(b);
    });
    body.appendChild(status);
    let confirm;
    openModal("State Grant", body, [
      { label: "Take resources", cls: "btn-primary", fn: () => { picks.forEach((r) => pl.res[r]++); log("took 2 resources via State Grant.", pl); closeModal(); renderAll(); } },
      { label: "Cancel", cls: "btn-ghost", fn: () => { pl.dev.push("plenty"); G.devPlayedThisTurn = false; closeModal(); renderAll(); } },
    ]);
    confirm = document.querySelector("#modal-actions .btn-primary"); confirm.disabled = true;
  }

  function openMonopolyModal() {
    const pl = cur();
    const body = document.createElement("div");
    body.innerHTML = "<p>Funding Mandate: name one resource. Every other district must hand you all of theirs.</p>";
    RES.forEach((r) => {
      const b = document.createElement("button"); b.className = "btn btn-ghost"; b.style.margin = "3px";
      b.innerHTML = RES_META[r].icon + " " + RES_META[r].name;
      b.addEventListener("click", () => {
        let total = 0;
        G.players.forEach((op) => { if (op.id !== pl.id) { total += op.res[r]; op.res[r] = 0; } });
        pl.res[r] += total;
        log("issued a Funding Mandate on " + RES_META[r].name + " — collected " + total + RES_META[r].icon + ".", pl);
        closeModal(); renderAll();
      });
      body.appendChild(b);
    });
    openModal("Funding Mandate", body, []);
  }

  function openWinModal(pl) {
    const body = document.createElement("div");
    body.className = "winner-box";
    body.innerHTML = '<div class="trophy">🏆</div><h3 style="margin:6px 0">' + escapeHtml(pl.name) + " wins!</h3>" +
      "<p>Reached " + totalVP(pl) + " victory points and built the county's strongest district.</p>";
    openModal("Victory", body, [
      { label: "New game", cls: "btn-primary", fn: () => location.reload() },
      { label: "View board", cls: "btn-ghost", fn: closeModal },
    ]);
  }

  /* ============================================================
     AI  (simple greedy opponent)
     ============================================================ */
  function maybeAITurn() { if (G.winner === null && cur().isAI) setTimeout(aiTurn, 700); }
  function maybeAIPlay() { if (G.winner === null && cur().isAI) setTimeout(aiPlay, 650); }

  function aiTurn() {
    if (G.winner !== null || !cur().isAI) return;
    roll(); // roll() will chain into aiPlay via distribute path, or robber path
  }

  function aiSetup() {
    const pl = cur();
    // choose best empty vertex by production pips + resource variety
    let best = null, bestScore = -1;
    G.vertices.forEach((v) => {
      if (!canPlaceSettlement(v.id, pl, false)) return;
      let score = 0; const kinds = new Set();
      v.hexes.forEach((hId) => { const h = G.hexes[hId]; if (h.resource !== "vacant") { score += pip(h.number); kinds.add(h.resource); } });
      score += kinds.size * 1.5;
      if (v.port) score += 0.5;
      if (score > bestScore) { bestScore = score; best = v.id; }
    });
    if (best !== null) placeSetupSettlement(best);
  }

  function aiSetupRoad() {
    const pl = cur();
    const vId = G.setupPendingVertex;
    // pick an edge from the settlement toward the highest-value open neighbor
    const opts = G.vertices[vId].edges.filter((eId) => canPlaceRoad(eId, pl));
    if (opts.length === 0) { // fallback any valid
      const any = G.edges.filter((e) => canPlaceRoad(e.id, pl)).map((e) => e.id);
      if (any.length) placeSetupRoad(any[0]);
      else { G.setupStep++; beginSetupStep(); }
      return;
    }
    let best = opts[0], bestScore = -1;
    opts.forEach((eId) => {
      const e = G.edges[eId];
      const other = e.v[0] === vId ? e.v[1] : e.v[0];
      let score = 0;
      G.vertices[other].hexes.forEach((hId) => { const h = G.hexes[hId]; if (h.resource !== "vacant") score += pip(h.number); });
      if (score > bestScore) { bestScore = score; best = eId; }
    });
    placeSetupRoad(best);
  }

  function aiDiscard(pl) {
    let need = Math.floor(handSize(pl) / 2);
    // discard from most-plentiful resources
    while (need > 0) {
      let r = RES.slice().sort((a, b) => pl.res[b] - pl.res[a])[0];
      if (pl.res[r] <= 0) break;
      pl.res[r]--; need--;
    }
    log("discarded cards to the budget cut.", pl);
  }

  function aiMoveRobber() {
    const pl = cur();
    // move to a hex touching the leading opponent, not touching self
    let bestHex = null, bestScore = -1;
    G.hexes.forEach((h) => {
      if (h.id === G.robberHex || h.resource === "vacant") return;
      let touchesSelf = false, score = 0;
      h.corners.forEach((vId) => {
        const v = G.vertices[vId];
        if (!v.building) return;
        if (v.building.player === pl.id) touchesSelf = true;
        else score += totalVP(G.players[v.building.player]) + handSize(G.players[v.building.player]) * 0.2;
      });
      if (touchesSelf) score -= 100;
      if (score > bestScore) { bestScore = score; bestHex = h.id; }
    });
    if (bestHex === null) bestHex = G.hexes.find((h) => h.id !== G.robberHex).id;
    moveRobber(bestHex, pl, () => { renderAll(); if (G.phase === "play") maybeAIPlay(); });
  }

  function aiPlay() {
    if (G.winner !== null || !cur().isAI) return;
    const pl = cur();

    // play a knight early if it helps grab largest army and we have one
    if (!G.devPlayedThisTurn && pl.dev.includes("knight") && pl.playedKnights >= ARMY_MIN - 1 && !pl.hasLargest) {
      const i = pl.dev.indexOf("knight"); pl.dev.splice(i, 1);
      pl.playedKnights++; G.devPlayedThisTurn = true;
      log("deployed an Administrator. 👔", pl);
      updateLargestArmy();
      aiMoveRobber();
      return; // aiMoveRobber re-enters aiPlay
    }

    let acted = true, guard = 0;
    while (acted && guard++ < 30) {
      acted = false;
      if (G.winner !== null) return;

      // 1) city
      if (pl.settlements.length > 0 && aiEnsure(pl, COST.city)) {
        const vId = aiBestCity(pl);
        if (vId !== null) { buildCityAI(vId); acted = true; if (G.winner !== null) return; continue; }
      }
      // 2) settlement
      if (anyValidSettlement(pl, true) && aiEnsure(pl, COST.settlement)) {
        const vId = aiBestSettlement(pl);
        if (vId !== null) { buildSettlementAI(vId); acted = true; if (G.winner !== null) return; continue; }
      }
      // 3) buy dev if flush
      if (G.devDeck.length && handSize(pl) >= 7 && aiEnsure(pl, COST.dev)) {
        buyDevAI(); acted = true; continue;
      }
      // 4) road toward expansion
      if (anyValidRoad(pl) && pl.roads.length < 14 && aiWantsRoad(pl) && aiEnsure(pl, COST.road)) {
        const eId = aiBestRoad(pl);
        if (eId !== null) { buildRoadAI(eId); acted = true; continue; }
      }
    }
    setTimeout(() => { if (G.winner === null) endTurn(); }, 400);
  }

  // AI build wrappers (no MODE juggling)
  function buildCityAI(vId) {
    const pl = cur(); pay(pl, COST.city);
    G.vertices[vId].building = { type: "city", player: pl.id };
    pl.settlements = pl.settlements.filter((s) => s !== vId); pl.cities.push(vId);
    log("consolidated a campus. 🏛️", pl); renderAll(); checkWin();
  }
  function buildSettlementAI(vId) {
    const pl = cur(); pay(pl, COST.settlement);
    G.vertices[vId].building = { type: "settlement", player: pl.id }; pl.settlements.push(vId);
    log("opened a new school.", pl); updateLongestRoad(); renderAll(); checkWin();
  }
  function buildRoadAI(eId) {
    const pl = cur(); pay(pl, COST.road);
    G.edges[eId].road = pl.id; pl.roads.push(eId);
    log("built a bus route.", pl); updateLongestRoad(); renderAll(); checkWin();
  }
  function buyDevAI() {
    const pl = cur(); pay(pl, COST.dev);
    const card = G.devDeck.pop();
    if (card.startsWith("vp:")) { pl.dev.push(card); pl.vpCards++; log("filed a landmark policy. 🏆", pl); checkWin(); }
    else { pl.newDev.push(card); log("bought a policy card.", pl); }
    renderAll();
  }

  // Try to make `cost` affordable via 4:1/port bank trades. Returns true if affordable now.
  function aiEnsure(pl, cost) {
    if (canAfford(pl, cost)) return true;
    let guard = 0;
    while (!canAfford(pl, cost) && guard++ < 20) {
      // find a needed resource
      const need = Object.keys(cost).find((r) => pl.res[r] < cost[r]);
      if (!need) break;
      // find a surplus resource to trade away (not itself needed)
      let gaveSomething = false;
      const cand = RES.filter((r) => r !== need)
        .map((r) => ({ r, rate: tradeRate(pl, r) }))
        .sort((a, b) => a.rate - b.rate);
      for (const c of cand) {
        const keepFor = cost[c.r] || 0;
        if (pl.res[c.r] - c.rate >= keepFor) {
          pl.res[c.r] -= c.rate; pl.res[need]++;
          log("traded " + c.rate + RES_META[c.r].icon + " → 1" + RES_META[need].icon + " with the bank.", pl);
          gaveSomething = true; break;
        }
      }
      if (!gaveSomething) break;
    }
    return canAfford(pl, cost);
  }

  function aiBestCity(pl) {
    let best = null, bestScore = -1;
    pl.settlements.forEach((vId) => {
      let score = 0;
      G.vertices[vId].hexes.forEach((hId) => { const h = G.hexes[hId]; if (h.resource !== "vacant") score += pip(h.number); });
      if (score > bestScore) { bestScore = score; best = vId; }
    });
    return best;
  }
  function aiBestSettlement(pl) {
    let best = null, bestScore = -1;
    G.vertices.forEach((v) => {
      if (!canPlaceSettlement(v.id, pl, true)) return;
      let score = 0; const kinds = new Set();
      v.hexes.forEach((hId) => { const h = G.hexes[hId]; if (h.resource !== "vacant") { score += pip(h.number); kinds.add(h.resource); } });
      score += kinds.size + (v.port ? 1 : 0);
      if (score > bestScore) { bestScore = score; best = v.id; }
    });
    return best;
  }
  function aiWantsRoad(pl) {
    // build roads only if it might open a new settlement spot and we don't already have one available
    return !anyValidSettlement(pl, true) || pl.roads.length < 3;
  }
  function aiBestRoad(pl) {
    let best = null, bestScore = -1;
    G.edges.forEach((e) => {
      if (!canPlaceRoad(e.id, pl)) return;
      // value: does it reach toward a buildable vertex?
      let score = Math.random();
      e.v.forEach((vId) => {
        if (canPlaceSettlement(vId, pl, false)) {
          G.vertices[vId].hexes.forEach((hId) => { const h = G.hexes[hId]; if (h.resource !== "vacant") score += pip(h.number); });
        }
        vertexNeighbors(vId).forEach((nb) => {
          if (canPlaceSettlement(nb, pl, false)) score += 1;
        });
      });
      if (score > bestScore) { bestScore = score; best = e.id; }
    });
    return best;
  }

  /* ---------------- Start screen wiring ---------------- */
  function buildPlayerConfig() {
    const n = +document.getElementById("numPlayers").value;
    const wrap = document.getElementById("playerConfig");
    wrap.innerHTML = "";
    for (let i = 0; i < n; i++) {
      const row = document.createElement("div"); row.className = "player-row";
      row.innerHTML =
        '<span class="swatch" style="background:' + PLAYER_COLORS[i].fill + '"></span>' +
        '<input type="text" value="' + DEFAULT_NAMES[i] + '" data-name="' + i + '">' +
        '<label class="aitoggle"><input type="checkbox" data-ai="' + i + '"' + (i === 0 ? "" : " checked") + '> CPU</label>';
      wrap.appendChild(row);
    }
  }

  function startFromConfig() {
    const n = +document.getElementById("numPlayers").value;
    const defs = [];
    for (let i = 0; i < n; i++) {
      const name = document.querySelector('[data-name="' + i + '"]').value.trim() || DEFAULT_NAMES[i];
      const isAI = document.querySelector('[data-ai="' + i + '"]').checked;
      defs.push({ name, isAI });
    }
    document.getElementById("start-screen").hidden = true;
    document.getElementById("game-screen").hidden = false;
    newGame(defs);
  }

  document.getElementById("numPlayers").addEventListener("change", buildPlayerConfig);
  document.getElementById("startBtn").addEventListener("click", startFromConfig);
  document.getElementById("howtoBtn").addEventListener("click", () => {
    const h = document.getElementById("howto"); h.hidden = !h.hidden;
  });
  document.getElementById("closeHowto").addEventListener("click", () => { document.getElementById("howto").hidden = true; });

  buildPlayerConfig();
})();
